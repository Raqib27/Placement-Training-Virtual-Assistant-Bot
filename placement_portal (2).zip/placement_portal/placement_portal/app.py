from flask import Flask, render_template, url_for, request, session
import sqlite3
import secrets
import numpy
from flask import Flask, render_template, request
import json
import os
import time
import random
import google.generativeai as genai
genai.configure(api_key='AIzaSyAg6UtggTP8rYwWQ-oBhJQf7xDa7SyyhpE')
gemini_model = genai.GenerativeModel('gemini-pro')
chat = gemini_model.start_chat(history=[])

app = Flask(__name__)
chat_history = []

connection = sqlite3.connect('database.db')
cursor = connection.cursor()

command = """CREATE TABLE IF NOT EXISTS admin (Id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, password TEXT, mobile TEXT, email TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS user (Id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, password TEXT, mobile TEXT, email TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS video (Id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT,  file TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS audio (Id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT, file TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS pdf (Id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT, file TEXT)"""
cursor.execute(command)

command = """CREATE TABLE IF NOT EXISTS feedback (Id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, feedback TEXT)"""
cursor.execute(command)

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chatbot')
def chatbot():
    return render_template('chatbot.html')

@app.route('/home')
def home():
    return render_template('userlog.html')

@app.route('/admin')
def admin():
    return render_template('adminlog.html')

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        feed = request.form['feed']
        print(name, email, feed)

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()
        

        cursor.execute("insert into feedback values (NULL, ?,?,?)", [name, email, feed])
        connection.commit()

        cursor.execute("select * from feedback")
        result = cursor.fetchall()
        return render_template('feedback.html', result=result)

    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("select * from feedback")
    result = cursor.fetchall()
    return render_template('feedback.html', result=result)

@app.route('/user')
def user():
    return render_template('userlog.html')

@app.route('/python', methods=['GET', 'POST'])
def python():
    if request.method == 'POST':
        score = 0
        answers = {
            'q1': 'b',
            'q2': 'c',
            'q3': 'a',
            'q4': 'd',
            'q5': 'b',
            'q6': 'c',
            'q7': 'a',
            'q8': 'b',
            'q9': 'c',
            'q10': 'd'
        }
        for question, answer in answers.items():
            user_answer = request.form.get(question)
            if user_answer == answer:
                score += 1
        
        jobs = [
            "Junior Python Developer",
            "Python Software Engineer",
            "Python Data Analyst",
            "Python QA Engineer",
            "Python Developer Intern",
            "Python Web Developer",
            "Python Automation Engineer",
            "Python Machine Learning Engineer",
            "Python Backend Developer",
            "Python Full Stack Developer"
        ]
        
        msg =  f'Your score is {score}/10. Thank you for taking the quiz!'
        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        query = "SELECT * FROM video WHERE subject = 'python'"
        cursor.execute(query)
        video = cursor.fetchall()

        query = "SELECT * FROM pdf WHERE subject = 'python'"
        cursor.execute(query)
        pdf = cursor.fetchall()

        query = "SELECT * FROM audio WHERE subject = 'python'"
        cursor.execute(query)
        audio = cursor.fetchall()

        return render_template('python.html', job = jobs[score], msg=msg, video=video, audio=audio, pdf=pdf)
    return render_template('python.html')

@app.route('/html', methods=['GET', 'POST'])
def html():
    if request.method == 'POST':
        score = 0
        answers = {
            'q1': 'a',
            'q2': 'a',
            'q3': 'a',
            'q4': 'b',
            'q5': 'b',
            'q6': 'a',
            'q7': 'b',
            'q8': 'a',
            'q9': 'b',
            'q10': 'a'
        }
        for question, answer in answers.items():
            user_answer = request.form.get(question)
            if user_answer == answer:
                score += 1
        
        jobs = [
            "HTML Developer",
            "Front-end Web Developer",
            "HTML/CSS Specialist",
            "Web Designer",
            "UI Developer",
            "Web Developer",
            "Email Developer",
            "HTML5 Developer",
            "Web Content Specialist",
            "Junior Front-end Developer"
        ]
        msg =  f'Your score is {score}/10. Thank you for taking the quiz!'

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        query = "SELECT * FROM video WHERE subject = 'html'"
        cursor.execute(query)
        video = cursor.fetchall()

        query = "SELECT * FROM pdf WHERE subject = 'html'"
        cursor.execute(query)
        pdf = cursor.fetchall()

        query = "SELECT * FROM audio WHERE subject = 'html'"
        cursor.execute(query)
        audio = cursor.fetchall()

        return render_template('html.html', job=jobs[score], msg=msg, video=video, audio=audio, pdf=pdf)
    return render_template('html.html')

@app.route('/css', methods=['GET', 'POST'])
def css():
    if request.method == 'POST':
        score = 0
        answers = {
            'q1': 'c',
            'q2': 'a',
            'q3': 'b',
            'q4': 'd',
            'q5': 'c',
            'q6': 'b',
            'q7': 'a',
            'q8': 'c',
            'q9': 'b',
            'q10': 'a'
        }
        for question, answer in answers.items():
            user_answer = request.form.get(question)
            if user_answer == answer:
                score += 1
        
        jobs = [
            "CSS Developer",
            "Front-end Web Developer",
            "UI Developer",
            "Web Designer",
            "CSS Specialist",
            "Front-end Engineer",
            "Web Stylist",
            "Web Layout Designer",
            "Front-end Architect",
            "CSS Consultant"
        ]
        
        msg =  f'Your score is {score}/10. Thank you for taking the quiz!'

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        query = "SELECT * FROM video WHERE subject = 'css'"
        cursor.execute(query)
        video = cursor.fetchall()

        query = "SELECT * FROM pdf WHERE subject = 'css'"
        cursor.execute(query)
        pdf = cursor.fetchall()

        query = "SELECT * FROM audio WHERE subject = 'css'"
        cursor.execute(query)
        audio = cursor.fetchall()

        return render_template('css.html', job=jobs[score], msg=msg, video=video, audio=audio, pdf=pdf)
    return render_template('css.html')

@app.route('/js', methods=['GET', 'POST'])
def js():
    if request.method == 'POST':
        score = 0
        answers = {
            'q1': 'b',
            'q2': 'c',
            'q3': 'a',
            'q4': 'd',
            'q5': 'b',
            'q6': 'c',
            'q7': 'a',
            'q8': 'b',
            'q9': 'c',
            'q10': 'd'
        }
        for question, answer in answers.items():
            user_answer = request.form.get(question)
            if user_answer == answer:
                score += 1
        
        jobs = [
            "JavaScript Developer",
            "Front-end Developer",
            "Full-stack Developer",
            "UI Developer",
            "Web Developer",
            "JavaScript Engineer",
            "Front-end Engineer",
            "Node.js Developer",
            "React Developer",
            "Angular Developer"
        ]

        msg = f'Your score is {score}/10. Thank you for taking the quiz!'

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        query = "SELECT * FROM video WHERE subject = 'js'"
        cursor.execute(query)
        video = cursor.fetchall()

        query = "SELECT * FROM pdf WHERE subject = 'js'"
        cursor.execute(query)
        pdf = cursor.fetchall()

        query = "SELECT * FROM audio WHERE subject = 'js'"
        cursor.execute(query)
        audio = cursor.fetchall()

        return render_template('js.html', job=jobs[score], msg=msg, video=video, audio=audio, pdf=pdf)
    return render_template('js.html')

@app.route('/adminlog', methods=['GET', 'POST'])
def adminlog():
    if request.method == 'POST':

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        email = request.form['name']
        password = request.form['password']

        query = "SELECT * FROM admin WHERE email = '"+email+"' AND password= '"+password+"'"
        cursor.execute(query)

        result = cursor.fetchone()

        if result:
            return render_template('adminlog.html')
        else:
            return render_template('index.html', msg='Sorry, Incorrect Credentials Provided,  Try Again')
    return render_template('index.html')

@app.route('/adminreg', methods=['GET', 'POST'])
def adminreg():
    if request.method == 'POST':

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        
        print(name, mobile, email, password)

        cursor.execute("INSERT INTO admin VALUES (NULL, '"+name+"', '"+password+"', '"+mobile+"', '"+email+"')")
        connection.commit()

        return render_template('index.html', msg='Successfully Registered')
    
    return render_template('index.html')


@app.route('/userlog', methods=['GET', 'POST'])
def userlog():
    if request.method == 'POST':

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        email = request.form['name']
        password = request.form['password']

        query = "SELECT * FROM user WHERE email = '"+email+"' AND password= '"+password+"'"
        cursor.execute(query)
        result = cursor.fetchall()

        if result:
            return render_template('userlog.html')
        else:
            return render_template('index.html', msg='Sorry, Incorrect Credentials Provided,  Try Again')

    return render_template('index.html')

@app.route('/userreg', methods=['GET', 'POST'])
def userreg():
    if request.method == 'POST':

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        
        print(name, mobile, email, password)

        cursor.execute("INSERT INTO user VALUES (NULL, '"+name+"', '"+password+"', '"+mobile+"', '"+email+"')")
        connection.commit()

        return render_template('index.html', msg='Successfully Registered')
    
    return render_template('index.html')

@app.route('/video', methods=['GET', 'POST'])
def video():
    if request.method == 'POST':
        subject = request.form['subject']
        link = request.form['link']

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        cursor.execute("INSERT INTO video VALUES (NULL, '"+subject+"', '"+link+"')")
        connection.commit()

        return render_template('adminlog.html')
       
    return render_template('adminlog.html')

@app.route('/audio', methods=['GET', 'POST'])
def audio():
    if request.method == 'POST':
        subject = request.form['subject']
        file = request.form['file']

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        cursor.execute("INSERT INTO audio VALUES (NULL, '"+subject+"', '"+file+"')")
        connection.commit()

        return render_template('audio.html')
       
    return render_template('audio.html')

@app.route('/pdf', methods=['GET', 'POST'])
def pdf():
    if request.method == 'POST':
        subject = request.form['subject']
        file = request.form['file']

        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()

        cursor.execute("INSERT INTO pdf VALUES (NULL, '"+subject+"', '"+file+"')")
        connection.commit()

        return render_template('pdf.html')
       
    return render_template('pdf.html')

@app.route('/chatting', methods=['GET', 'POST'])
def chatting():
    if request.method == 'POST':
        user_input = request.form['query']
        gemini_response = chat.send_message(user_input)
        data = gemini_response.text
        chat_history.append([user_input, data])
        return render_template('chatbot.html', chat_history=chat_history)
    return render_template('chatbot.html')


@app.route('/logout')
def logout():
    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
